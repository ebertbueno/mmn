<div class="copy">
            <p>Copyright &copy; 2016 <?php print $site_name ?> . All Rights Reserved | Site desenvolvido por <a href="http://perfil.mercadolivre.com.br/SHOPWEBDESIGNER" target="_blank">SHOPWEBDESIGNER</a>
	    </div>